export const ItemTypes = {
  FIELD: "field",
  SECTION: "section",
};