import { FormValues, FormSchema } from '../types';

/**
 * Storage service for form data persistence
 */
export class FormStorageService {
  private static PREFIX = 'form_builder_';

  /**
   * Save form values to local storage
   */
  static saveFormValues(formId: string, values: FormValues): void {
    try {
      localStorage.setItem(`${this.PREFIX}${formId}`, JSON.stringify(values));
    } catch (error) {
      console.error('Failed to save form values:', error);
    }
  }

  /**
   * Load form values from local storage
   */
  static loadFormValues(formId: string): FormValues | null {
    try {
      const data = localStorage.getItem(`${this.PREFIX}${formId}`);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Failed to load form values:', error);
      return null;
    }
  }

  /**
   * Save form schema to local storage
   */
  static saveFormSchema(formId: string, schema: FormSchema): void {
    try {
      localStorage.setItem(`${this.PREFIX}schema_${formId}`, JSON.stringify(schema));
    } catch (error) {
      console.error('Failed to save form schema:', error);
    }
  }

  /**
   * Load form schema from local storage
   */
  static loadFormSchema(formId: string): FormSchema | null {
    try {
      const data = localStorage.getItem(`${this.PREFIX}schema_${formId}`);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Failed to load form schema:', error);
      return null;
    }
  }

  /**
   * Clear form data from local storage
   */
  static clearFormData(formId: string): void {
    try {
      localStorage.removeItem(`${this.PREFIX}${formId}`);
      localStorage.removeItem(`${this.PREFIX}schema_${formId}`);
    } catch (error) {
      console.error('Failed to clear form data:', error);
    }
  }
}
