export * from './api';
export * from './storage';

import { FormSchema, FormValues } from '../types';

/**
 * FormSchemaService - Handles loading and processing form schemas
 */
export class FormSchemaService {
  /**
   * Fetches a form schema from a provided endpoint
   */
  static async fetchSchema(schemaId: string, endpoint: string = '/api/schemas'): Promise<FormSchema> {
    try {
      const response = await fetch(`${endpoint}/${schemaId}`);
      if (!response.ok) {
        throw new Error(`Failed to fetch schema: ${response.statusText}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error fetching form schema:', error);
      throw error;
    }
  }

  /**
   * Submits form data to a specified endpoint
   */
  static async submitForm(
    formValues: FormValues, 
    endpoint: string = '/api/submit',
    options: RequestInit = {}
  ): Promise<any> {
    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formValues),
        ...options
      });
      
      if (!response.ok) {
        throw new Error(`Form submission failed: ${response.statusText}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error submitting form:', error);
      throw error;
    }
  }
}

export default FormSchemaService;
