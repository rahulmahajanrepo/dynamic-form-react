import { FormSchema, FormValues } from '../types';

// Simple API service for form builder operations

export const formBuilderApi = {
  saveForm: async (formData: any): Promise<any> => {
    try {
      // Simulate API call
      console.log('Saving form data:', formData);
      return { success: true, id: Date.now().toString() };
    } catch (error) {
      console.error('Error saving form:', error);
      throw error;
    }
  },
  
  loadForm: async (formId: string): Promise<any> => {
    try {
      // Simulate API call
      console.log('Loading form with ID:', formId);
      return { id: formId, fields: [], title: 'Loaded Form' };
    } catch (error) {
      console.error('Error loading form:', error);
      throw error;
    }
  }
};

/**
 * API service for form operations
 */
export class FormApiService {
  static async fetchSchema(schemaId: string, endpoint: string = '/api/schemas'): Promise<FormSchema> {
    try {
      const response = await fetch(`${endpoint}/${schemaId}`);
      if (!response.ok) {
        throw new Error(`Failed to fetch schema: ${response.statusText}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error fetching form schema:', error);
      throw error;
    }
  }

  static async submitForm(
    formValues: FormValues, 
    endpoint: string = '/api/submit',
    options: RequestInit = {}
  ): Promise<any> {
    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formValues),
        ...options
      });
      
      if (!response.ok) {
        throw new Error(`Form submission failed: ${response.statusText}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error submitting form:', error);
      throw error;
    }
  }
}
