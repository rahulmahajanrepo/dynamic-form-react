export const FIELD_TYPES = {
  TEXT: 'text',
  NUMBER: 'number',
  EMAIL: 'email',
  PASSWORD: 'password',
  SELECT: 'select',
  CHECKBOX: 'checkbox',
  RADIO: 'radio',
  TEXTAREA: 'textarea',
  DATE: 'date',
  FILE: 'file',
  HEADING: 'heading'
} as const;

export type FieldType = typeof FIELD_TYPES[keyof typeof FIELD_TYPES];

export const FIELD_TYPE_LABELS = {
  [FIELD_TYPES.TEXT]: 'Text',
  [FIELD_TYPES.NUMBER]: 'Number',
  [FIELD_TYPES.EMAIL]: 'Email',
  [FIELD_TYPES.PASSWORD]: 'Password',
  [FIELD_TYPES.TEXTAREA]: 'Text Area',
  [FIELD_TYPES.SELECT]: 'Dropdown',
  [FIELD_TYPES.CHECKBOX]: 'Checkbox',
  [FIELD_TYPES.RADIO]: 'Radio Button',
  [FIELD_TYPES.DATE]: 'Date Picker',
  [FIELD_TYPES.FILE]: 'File Upload',
  [FIELD_TYPES.HEADING]: 'Heading'
};
