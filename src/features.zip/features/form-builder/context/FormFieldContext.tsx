import React, { createContext, useContext, ReactNode } from 'react';
import { FieldSchema } from '../types';
import { useFormBuilder } from './FormBuilderContext';

interface FormFieldContextProps {
  field: FieldSchema;
  value: any;
  error: string | undefined;
  onChange: (value: any) => void;
  onBlur: () => void;
}

const FormFieldContext = createContext<FormFieldContextProps | undefined>(undefined);

export const FormFieldProvider = ({ 
  children, 
  field 
}: { 
  children: ReactNode;
  field: FieldSchema;
}) => {
  const { values, errors, updateValue } = useFormBuilder();
  
  const value = values[field.name];
  const error = errors[field.name];
  
  const onChange = (newValue: any) => {
    updateValue(field.name, newValue);
  };
  
  const onBlur = () => {
    // Handle field blur event if needed
  };

  return (
    <FormFieldContext.Provider
      value={{
        field,
        value,
        error,
        onChange,
        onBlur,
      }}
    >
      {children}
    </FormFieldContext.Provider>
  );
};

export const useFormField = () => {
  const context = useContext(FormFieldContext);
  if (context === undefined) {
    throw new Error('useFormField must be used within a FormFieldProvider');
  }
  return context;
};
