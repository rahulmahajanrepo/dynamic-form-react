import React, { createContext, useContext, useState, ReactNode } from 'react';
import { FormSchema, FormValues } from '../types';

interface FormBuilderContextProps {
  schema: FormSchema | null;
  values: FormValues;
  errors: Record<string, string>;
  setSchema: (schema: FormSchema) => void;
  setValues: (values: FormValues) => void;
  updateValue: (fieldName: string, value: any) => void;
  setErrors: (errors: Record<string, string>) => void;
  resetForm: () => void;
}

const FormBuilderContext = createContext<FormBuilderContextProps | undefined>(undefined);

export const FormBuilderProvider = ({ children }: { children: ReactNode }) => {
  const [schema, setSchema] = useState<FormSchema | null>(null);
  const [values, setValues] = useState<FormValues>({});
  const [errors, setErrors] = useState<Record<string, string>>({});

  const updateValue = (fieldName: string, value: any) => {
    setValues((prev) => ({
      ...prev,
      [fieldName]: value,
    }));
  };

  const resetForm = () => {
    setValues({});
    setErrors({});
  };

  return (
    <FormBuilderContext.Provider
      value={{
        schema,
        values,
        errors,
        setSchema,
        setValues,
        updateValue,
        setErrors,
        resetForm,
      }}
    >
      {children}
    </FormBuilderContext.Provider>
  );
};

export const useFormBuilder = () => {
  const context = useContext(FormBuilderContext);
  if (context === undefined) {
    throw new Error('useFormBuilder must be used within a FormBuilderProvider');
  }
  return context;
};
