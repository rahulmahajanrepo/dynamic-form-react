export { default as DroppableArea } from './DroppableArea';
// Export other core components as they're created
