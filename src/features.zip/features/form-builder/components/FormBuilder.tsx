import React, { ReactNode, useEffect } from 'react';
import { FormBuilderProvider } from '../context/FormBuilderContext';
import { FormSchema, FormValues } from '../types';
import { useFormBuilder } from '../hooks/useFormBuilder';

// Add this empty export to make it a module if no other exports exist
export {};

interface FormBuilderProps {
  schema: FormSchema;
  initialValues?: FormValues;
  onSubmit: (values: FormValues) => void;
  children: ReactNode;
}

// Form content component that uses the context
const FormContent = ({
  schema,
  initialValues,
  onSubmit,
  children,
}: Omit<FormBuilderProps, 'schema'> & { schema: FormSchema }) => {
  const { initializeForm, submitForm } = useFormBuilder();

  useEffect(() => {
    initializeForm(schema, initialValues);
  }, [schema, initialValues, initializeForm]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await submitForm(onSubmit);
  };

  return (
    <form onSubmit={handleSubmit}>
      {children}
    </form>
  );
};

// Main FormBuilder component that provides the context
export const FormBuilder = (props: FormBuilderProps) => {
  return (
    <FormBuilderProvider>
      <FormContent {...props} />
    </FormBuilderProvider>
  );
};
