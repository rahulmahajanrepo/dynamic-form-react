import React from 'react';
import { FormSection } from './FormSection';

// Export layout components
export { FormSection };

// Add other layout components or utilities
export const FormRow: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="form-row">{children}</div>
);

export const FormColumn: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="form-column">{children}</div>
);
