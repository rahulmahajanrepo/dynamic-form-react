import React from 'react';
import { useFormField } from '../../hooks';

export const TextField = () => {
  const { field, value, error, onChange } = useFormField();
  
  return (
    <div className="form-field">
      <label htmlFor={field.name}>{field.label}</label>
      <input
        id={field.name}
        type="text"
        value={value || ''}
        onChange={(e) => onChange(e.target.value)}
        placeholder={field.placeholder}
        disabled={field.disabled}
        required={field.required}
      />
      {error && <div className="field-error">{error}</div>}
    </div>
  );
};
