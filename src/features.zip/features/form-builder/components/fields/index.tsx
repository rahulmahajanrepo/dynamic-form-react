import React from 'react';
import { FieldSchema } from '../../types';
import { TextField } from './TextField';
import { SelectField } from './SelectField';

// This is a registry of field components
export const FieldComponents: Record<string, React.ComponentType<any>> = {
  text: TextField,
  select: SelectField,
  // Add other field components as needed
};

// Field renderer component
export const Field: React.FC<{ field: FieldSchema }> = ({ field }) => {
  const FieldComponent = FieldComponents[field.type];
  
  if (!FieldComponent) {
    console.warn(`Field type '${field.type}' is not supported`);
    return null;
  }
  
  return <FieldComponent field={field} />;
};

export * from './TextField';
export * from './SelectField';
