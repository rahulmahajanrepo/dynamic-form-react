import React from 'react';
import { useFormField } from '../../hooks';

export const SelectField = () => {
  const { field, value, error, onChange } = useFormField();
  
  return (
    <div className="form-field">
      <label htmlFor={field.name}>{field.label}</label>
      <select
        id={field.name}
        value={value || ''}
        onChange={(e) => onChange(e.target.value)}
        disabled={field.disabled}
        required={field.required}
      >
        <option value="">Select an option</option>
        {field.options?.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {error && <div className="field-error">{error}</div>}
    </div>
  );
};
