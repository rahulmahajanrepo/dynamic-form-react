import { useState, useCallback, useEffect } from 'react';

export * from './useFormBuilder';
export * from './useFormField';

/**
 * Hook for managing form state
 */
export const useFormState = <T extends Record<string, any>>(initialState: T) => {
  const [formState, setFormState] = useState<T>(initialState);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isDirty, setIsDirty] = useState<boolean>(false);

  const handleChange = useCallback((name: string, value: any) => {
    setFormState(prev => ({
      ...prev,
      [name]: value
    }));
    setIsDirty(true);
  }, []);

  const reset = useCallback(() => {
    setFormState(initialState);
    setErrors({});
    setIsDirty(false);
  }, [initialState]);

  return {
    formState,
    errors,
    isDirty,
    handleChange,
    setErrors,
    reset
  };
};

/**
 * Hook for field-level validation
 */
export const useFieldValidation = (validate: (value: any) => string | null) => {
  const [error, setError] = useState<string | null>(null);
  
  const validateField = useCallback((value: any) => {
    const errorMessage = validate(value);
    setError(errorMessage);
    return !errorMessage;
  }, [validate]);

  return {
    error,
    validateField
  };
};

// Placeholder file for hooks exports
// Add your custom hooks here as needed
export {};
