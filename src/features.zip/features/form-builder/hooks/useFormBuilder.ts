import { useCallback } from 'react';
import { useFormBuilder as useFormBuilderContext } from '../context/FormBuilderContext';
import { FormSchema, FormValues } from '../types';
import { validateForm } from '../utils/validation';

export const useFormBuilder = () => {
  const context = useFormBuilderContext();
  
  const initializeForm = useCallback((schema: FormSchema, initialValues?: FormValues) => {
    context.setSchema(schema);
    if (initialValues) {
      context.setValues(initialValues);
    } else {
      // Initialize with default values from schema
      const defaultValues: FormValues = {};
      schema.fields.forEach(field => {
        if (field.defaultValue !== undefined) {
          defaultValues[field.name] = field.defaultValue;
        }
      });
      context.setValues(defaultValues);
    }
  }, [context]);

  const submitForm = useCallback(async (onSubmit: (values: FormValues) => void) => {
    if (!context.schema) return;
    
    const errors = validateForm(context.values, context.schema);
    context.setErrors(errors);
    
    if (Object.keys(errors).length === 0) {
      onSubmit(context.values);
    }
    
    return Object.keys(errors).length === 0;
  }, [context]);

  return {
    ...context,
    initializeForm,
    submitForm,
  };
};
