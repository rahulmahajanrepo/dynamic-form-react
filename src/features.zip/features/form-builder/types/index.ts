export interface FieldOption {
  value: string | number;
  label: string;
}

export interface FieldValidation {
  required?: boolean;
  pattern?: string;
  message?: string;
  min?: number;
  max?: number;
  minLength?: number;
  maxLength?: number;
  custom?: (value: any) => string | undefined;
}

export interface FieldSchema {
  type: 'text' | 'number' | 'email' | 'password' | 'select' | 'checkbox' | 'radio' | 'textarea';
  name: string;
  label?: string;
  placeholder?: string;
  defaultValue?: any;
  options?: FieldOption[];
  disabled?: boolean;
  required?: boolean;
  validation?: FieldValidation | ((value: any) => string | undefined);
}

export interface FormSchema {
  id?: string;
  title?: string;
  description?: string;
  fields: FieldSchema[];
}

export type FormValues = Record<string, any>;

export interface FieldConfig {
  id: string;
  type: string;
  label: string;
  options?: FieldOption[];
  // Add other field properties as needed
}

export interface ValidationRules {
  required?: boolean;
  minLength?: number;
  maxLength?: number;
  pattern?: RegExp;
  // Add other validation rules as needed
}
