import { FieldSchema, FormSchema, FormValues } from '../types';

export const validateField = (value: any, field: FieldSchema): string | undefined => {
  if (field.required && (value === undefined || value === null || value === '')) {
    return `${field.label || field.name} is required`;
  }
  
  if (field.validation) {
    // Check custom validation rules
    if (typeof field.validation === 'function') {
      return field.validation(value);
    }
    
    // Check regex pattern
    if (field.validation.pattern && value) {
      const regex = new RegExp(field.validation.pattern);
      if (!regex.test(String(value))) {
        return field.validation.message || `Invalid format for ${field.label || field.name}`;
      }
    }
    
    // Check min/max for numbers
    if (field.type === 'number' && value !== undefined && value !== null) {
      const numValue = Number(value);
      
      if (field.validation.min !== undefined && numValue < field.validation.min) {
        return `Value must be at least ${field.validation.min}`;
      }
      
      if (field.validation.max !== undefined && numValue > field.validation.max) {
        return `Value must be at most ${field.validation.max}`;
      }
    }
    
    // Check min/max length for strings
    if (typeof value === 'string') {
      if (field.validation.minLength !== undefined && value.length < field.validation.minLength) {
        return `Must be at least ${field.validation.minLength} characters`;
      }
      
      if (field.validation.maxLength !== undefined && value.length > field.validation.maxLength) {
        return `Must be at most ${field.validation.maxLength} characters`;
      }
    }
  }
  
  return undefined;
};

export const validateForm = (values: FormValues, schema: FormSchema): Record<string, string> => {
  const errors: Record<string, string> = {};
  
  schema.fields.forEach(field => {
    const error = validateField(values[field.name], field);
    if (error) {
      errors[field.name] = error;
    }
  });
  
  return errors;
};
