/**
 * Form Builder Utility Functions
 */

/**
 * Generates a unique ID for form elements
 */
export const generateUniqueId = (prefix: string = 'form-element'): string => {
  return `${prefix}-${Math.random().toString(36).substring(2, 11)}`;
};

/**
 * Validates if a string is not empty
 */
export const isNotEmpty = (value: string): boolean => {
  return value !== undefined && value !== null && value.trim() !== '';
};

/**
 * Deep clones an object
 */
export const deepClone = <T>(obj: T): T => {
  return JSON.parse(JSON.stringify(obj));
};

/**
 * Formats a label to a valid field name
 */
export const formatFieldName = (label: string): string => {
  return label
    .toLowerCase()
    .replace(/\s+/g, '_')
    .replace(/[^a-z0-9_]/g, '');
};
